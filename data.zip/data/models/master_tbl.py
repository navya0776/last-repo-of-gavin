# from sqlalchemy import String, Integer
# from sqlalchemy.orm import Mapped, mapped_column, relationship

# from .base import Base
# from .depot_demand import Demand
# from .cds import cds_table, JobMaster, CDS
# from .ledgers import Ledger


# class MasterTable(Base):
#     __tablename__ = "master_table"

#     Master_id: Mapped[int] = mapped_column(
#         Integer, nullable=False, primary_key=True, autoincrement=True
#     )

#     Ledger_code: Mapped[str] = mapped_column(
#         String(4), nullable=False
#     )

#     eqpt_code: Mapped[str] = mapped_column(String(4), nullable=False)
#     ledger_name: Mapped[str] = mapped_column(String(11), nullable=False)

#     eqpt_name: Mapped[str] = mapped_column(
#         String(15),
#         nullable=False
#     )

#     dmd: Mapped[list["Demand"]] = relationship(
#         "Demand",
#         back_populates="eqpt",
#         cascade="all, delete",
#         foreign_keys=[Demand.master_id]
#     )

#     cds_Eqpt: Mapped["CDS"] = relationship("CDS", back_populates="Eqpt_cds")

#     legder: Mapped[list["Ledger"]] = relationship(
#         "Ledger",
#         back_populates="Eqpt",
#         cascade="all, delete",
#         foreign_keys=[Ledger.Master_id],
#     )

#     job: Mapped[list["JobMaster"]] = relationship(
#         "JobMaster", back_populates="Eqpt", cascade="all, delete"
#     )

#     added_eqpt: Mapped["cds_table"] = relationship(
#         "cds_table",
#         back_populates="",
#         cascade="all, delete",
#         foreign_keys=[cds_table.Master_id],
#     )

from sqlalchemy import String, Integer, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import List, Optional

from .base import Base

# Note: We use string references in relationship() to avoid circular imports 
# if these classes import MasterTable back.

class MasterTable(Base):
    __tablename__ = "master_table"

    Master_id: Mapped[int] = mapped_column(
        Integer, nullable=False, primary_key=True, autoincrement=True
    )

    Ledger_code: Mapped[str] = mapped_column(
        String(4), nullable=False
    )
    
    # New column for direct Store mapping
    store_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("stores.store_id"), nullable=True
    )
    
    eqpt_code: Mapped[str] = mapped_column(String(4), nullable=False)
    ledger_name: Mapped[str] = mapped_column(String(11), nullable=False)

    eqpt_name: Mapped[str] = mapped_column(
        String(15),
        nullable=False
    )

    # --- Relationships ---

    # Direct link to the Store
    store: Mapped["Stores"] = relationship("Stores")

    # Link to Demands
    dmd: Mapped[List["Demand"]] = relationship(
        "Demand",
        back_populates="eqpt",
        cascade="all, delete",
        # Using string for foreign_keys avoids import order issues
        foreign_keys="Demand.master_id" 
    )

    # Link to CDS
    cds_Eqpt: Mapped["CDS"] = relationship("CDS", back_populates="Eqpt_cds")

    # Link to Ledger entries (kept your typo 'legder' to match your Ledger model)
    legder: Mapped[List["Ledger"]] = relationship(
        "Ledger",
        back_populates="Eqpt",
        cascade="all, delete",
        foreign_keys="Ledger.Master_id",
    )

    # Link to Jobs
    job: Mapped[List["JobMaster"]] = relationship(
        "JobMaster", 
        back_populates="Eqpt", 
        cascade="all, delete"
    )

    # Link to added_eqpt (Removed empty back_populates to prevent errors)
    added_eqpt: Mapped["cds_table"] = relationship(
        "cds_table",
        cascade="all, delete",
        foreign_keys="cds_table.Master_id",
    )