from logging import getLogger
from fastapi import HTTPException, status
from sqlalchemy import select, insert, func, case
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..schemas import (
    LedgerMaintanenceCreate,
    LedgerMaintanenceUpdate,
    LedgerMaintenanceResponse,
)

from backend.schemas.ledger.stk_analysis import StockCategoryBreakdown
from data.models.ledgers import Ledger, Stores
from data.models.master_tbl import MasterTable

logger = getLogger(__name__)

async def get_all_ledgers(session: AsyncSession, skip: int, limit: int):
    result = await session.execute(
        select(Stores)
        .options(selectinload(Stores.ledgers))
        .offset(skip)
        .limit(limit)
    )
    return result.scalars().all()


async def get_ledger_pages(
    ledger_code: str,
    session: AsyncSession,
    skip: int,
    limit: int,
) -> list[LedgerMaintenanceResponse]:
    stmt = (
        select(Ledger)
        .where(Ledger.Ledger_code == ledger_code)
        .offset(skip).limit(limit)
    )
    result = await session.stream_scalars(stmt)

    pages = []
    async for record in result:
        pages.append(
            LedgerMaintenanceResponse.model_validate(record, from_attributes=True)
        )

    return pages

async def add_page(
    ledger_code: str,
    ledger_page: LedgerMaintanenceCreate,
    session: AsyncSession,
):
    try:
        ledger = Ledger(
            **ledger_page.model_dump(),
            Ledger_code=ledger_code
        )

        session.add(ledger)
        await session.commit()
        await session.refresh(ledger)
        return ledger

    except SQLAlchemyError as e:
        logger.exception("Database error in add_page")
        raise HTTPException(500, "Database error") from e

async def update_page(
    ledger_code: str,
    ledger_page: LedgerMaintanenceUpdate,
    session: AsyncSession,
):
    try:
        stmt = (
            select(Ledger)
            .where(
                Ledger.Ledger_code == ledger_code,
                Ledger.ledger_page == ledger_page.ledger_page,
            )
            .with_for_update()  # optional row lock to prevent concurrent updates
        )
        result = await session.execute(stmt)
        record = result.scalar_one_or_none()

        if not record:
            raise HTTPException(status_code=404, detail="Page not found")

        # Apply updates (validated from Pydantic model)
        for key, value in ledger_page.model_dump(exclude_unset=True).items():
            setattr(record, key, value)

        # Transaction auto-commits on exit from `session.begin()`
        await session.flush()
        return status.HTTP_200_OK
    except:
        raise HTTPException(status_code=500, detail="Internal Server Error")


async def get_msc_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = select(
        Ledger.msc,
        func.count().label("total_qty"),
        func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
        func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
        func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
        func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
        func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
        func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
        func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
        func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label("stk_less_than_2"),
        func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label("stk_less_than_5"),
        func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label("stk_less_than_10"),
    ).where(Ledger.Ledger_code == ledger_code)
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "MSC analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_ved_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.ved,
            func.count().label("total_qty"),
            func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
            func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
            func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
            func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
            func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
            func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
            func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
            func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label(
                "stk_less_than_2"
            ),
            func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label(
                "stk_less_than_5"
            ),
            func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label(
                "stk_less_than_10"
            ),
        )
        .group_by(Ledger.ved)
        .where(Ledger.Ledger_code == ledger_code)
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        total = row["ser_stk"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk = (row["ser_stk"] / total * 100) if total else 0,  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0
    )


async def get_must_change_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.msc,
            func.count().label("total_qty"),
            func.sum(Ledger.unsv_stock).label("unsv_stk"),
            func.sum(Ledger.rep_stock).label("rep_stk"),
            func.sum(Ledger.serv_stock).label("ser_stk"),
            func.sum(Ledger.dues_in).label("D_in"),
            func.sum(Ledger.Re_ord_lvl).label("re_ord_lvl"),
            func.sum(Ledger.safety_stk).label("safety_stk"),
            func.count(Ledger.serv_stock == 0).label("zero_stk"),
            func.count(Ledger.serv_stock < 2).label("stk_less_than_2"),
            func.count(Ledger.serv_stock < 5).label("stk_less_than_5"),
            func.count(Ledger.serv_stock < 10).label("stk_less_than_10"),
        )
        .where(Ledger.Ledger_code == ledger_code)
        .where(Ledger.msc == "M")
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_shoud_change_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.msc,
            func.count().label("total_qty"),
            func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
            func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
            func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
            func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
            func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
            func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
            func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
            func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label(
                "stk_less_than_2"
            ),
            func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label(
                "stk_less_than_5"
            ),
            func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label(
                "stk_less_than_10"
            ),
        )
        .where(Ledger.Ledger_code == ledger_code)
        .where(Ledger.msc == "S")
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_could_change_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.msc,
            func.count().label("total_qty"),
            func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
            func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
            func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
            func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
            func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
            func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
            func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
            func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label(
                "stk_less_than_2"
            ),
            func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label(
                "stk_less_than_5"
            ),
            func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label(
                "stk_less_than_10"
            ),
        )
        .where(Ledger.Ledger_code == ledger_code)
        .where(Ledger.msc == "C")
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_vital_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.ved,
            func.count().label("total_qty"),
            func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
            func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
            func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
            func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
            func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
            func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
            func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
            func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label(
                "stk_less_than_2"
            ),
            func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label(
                "stk_less_than_5"
            ),
            func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label(
                "stk_less_than_10"
            ),
        )
        .group_by(Ledger.ved)
        .where(Ledger.Ledger_code == ledger_code)
        .where(Ledger.ved == "V")
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_essential_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.ved,
            func.count().label("total_qty"),
            func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
            func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
            func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
            func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
            func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
            func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
            func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
            func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label(
                "stk_less_than_2"
            ),
            func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label(
                "stk_less_than_5"
            ),
            func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label(
                "stk_less_than_10"
            ),
        )
        .where(Ledger.Ledger_code == ledger_code)
        .where(Ledger.ved == "E")
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_desirable_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.ved,
            func.count().label("total_qty"),
            func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
            func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
            func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
            func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
            func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
            func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
            func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
            func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label(
                "stk_less_than_2"
            ),
            func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label(
                "stk_less_than_5"
            ),
            func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label(
                "stk_less_than_10"
            ),
        )
        .where(Ledger.Ledger_code == ledger_code)
        .where(Ledger.ved == "D")
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_item_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = select(
        Ledger,
        func.count().label("total_qty"),
        func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
        func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
        func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
        func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
        func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
        func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
        func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
        func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label("stk_less_than_2"),
        func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label("stk_less_than_5"),
        func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label("stk_less_than_10"),
    ).where(Ledger.Ledger_code == ledger_code)
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_scaled_item_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.ohs_number,
            func.count().label("total_qty"),
            func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
            func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
            func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
            func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
            func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
            func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
            func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
            func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label(
                "stk_less_than_2"
            ),
            func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label(
                "stk_less_than_5"
            ),
            func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label(
                "stk_less_than_10"
            ),
        )
        .where(Ledger.Ledger_code == ledger_code)
        .where(Ledger.ohs_number != "NS")
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )


async def get_non_scaled_item_analysis(ledger_code: str, session: AsyncSession):
    """Compute stock breakdowns asynchronously."""
    # Example: group by M/S/C category
    msc_query = (
        select(
            Ledger.ohs_number,
            func.count().label("total_qty"),
            func.coalesce(func.sum(Ledger.unsv_stock), 0).label("unsv_stk"),
            func.coalesce(func.sum(Ledger.rep_stock), 0).label("rep_stk"),
            func.coalesce(func.sum(Ledger.serv_stock), 0).label("ser_stk"),
            func.coalesce(func.sum(Ledger.dues_in), 0).label("D_in"),
            func.coalesce(func.sum(Ledger.Re_ord_lvl), 0).label("re_ord_lvl"),
            func.coalesce(func.sum(Ledger.safety_stk), 0).label("safety_stk"),
            func.sum(case((Ledger.serv_stock == 0, 1), else_=0)).label("zero_stk"),
            func.sum(case((Ledger.serv_stock < 2, 1), else_=0)).label(
                "stk_less_than_2"
            ),
            func.sum(case((Ledger.serv_stock < 5, 1), else_=0)).label(
                "stk_less_than_5"
            ),
            func.sum(case((Ledger.serv_stock < 10, 1), else_=0)).label(
                "stk_less_than_10"
            ),
        )
        .where(Ledger.Ledger_code == ledger_code)
        .where(Ledger.ohs_number == "NS")
    )
    result = await session.execute(msc_query)
    row = result.mappings().first()

    assert row is not None, "VED analysis returned none even though ledger was found"

    # Convert ORM results → Pydantic models
    return StockCategoryBreakdown(
        total_qty=row["total_qty"] or 0,
        unsv_stk=row["unsv_stk"] or 0,
        rep_stk=row["rep_stk"] or 0,
        ser_stk=row["ser_stk"] or 0,
        per_stk=(
            row["ser_stk"] / row["tot_stk"] * 100
        ),  # You can compute percentage here later
        D_in=row["D_in"] or 0,
        tot_stk=row["ser_stk"]
        or 0,  # Yes i know i wrote set_stk, this is litterally what it is
        per_tot_stk=0,
        re_ord_lvl=row["re_ord_lvl"] or 0,
        safety_stk=row["safety_stk"] or 0,
        zero_stk=row["zero_stk"] or 0,
        stk_less_than_2=row["stk_less_than_2"] or 0,
        stk_less_than_5=row["stk_less_than_5"] or 0,
        stk_less_than_10=row["stk_less_than_10"] or 0,
    )
