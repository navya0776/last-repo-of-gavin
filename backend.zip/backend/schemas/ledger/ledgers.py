from typing import Optional, Literal
from datetime import date
from pydantic import BaseModel, model_validator, ConfigDict


# ============================================================
#                       STORE MODELS
# ============================================================
class StoreBase(BaseModel):
    store_name: str
    store_id: int


class StoreResponse(StoreBase):
    ledgers: list["LedgerResponse"]

+    model_config = ConfigDict(from_attributes=True)



# ============================================================
#                      LEDGER BASE MODELS
# ============================================================
class LedgerBase(BaseModel):
    Ledger_code: Optional[str] = None
    ledger_page: Optional[str] = None

    ohs_number: Optional[str] = None
    isg_number: Optional[str] = None
    ssg_number: Optional[str] = None

    part_number: Optional[str] = None
    nomenclature: Optional[str] = None
    a_u: Optional[str] = None

    no_off: Optional[int] = None
    scl_auth: Optional[int] = None

    stock: Optional[int] = 0
    unsv_stock: Optional[int] = 0
    rep_stock: Optional[int] = 0
    serv_stock: Optional[int] = 0

    msc: Optional[str] = None
    ved: Optional[str] = None
    in_house: Optional[str] = None

    dues_in: Optional[int] = None
    consumption: Optional[int] = None

    bin_number: Optional[str] = None
    group: Optional[str] = None

    cds_unsv_stock: Optional[int] = 0
    cds_rep_stock: Optional[int] = 0
    cds_serv_stock: Optional[int] = 0

    lpp: Optional[str] = None
    cos_sec: Optional[str] = None
    cab_no: Optional[str] = None
    old_pg_ref: Optional[float] = None

    Assy_Comp: Optional[str] = None
    Re_ord_lvl: Optional[int] = None
    safety_stk: Optional[int] = None
    lpp_dt: Optional[str] = None
    rate: Optional[float] = None
    Rmks: Optional[str] = None

    br_stock: Optional[int] = None
    br_stock_dt: Optional[date] = None

    cab: Optional[str] = None
    dem: Optional[int] = None
    dem_val: Optional[float] = None

    lock_dt: Optional[date] = None

    npart_no: Optional[str] = None
    nscl_no: Optional[str] = None

    old_page: Optional[str] = None

    p_stock_dt: Optional[date] = None
    qty: Optional[int] = None

    r_stock: Optional[int] = None
    r_stock_dt: Optional[date] = None

    sale_rate: Optional[float] = None
    sl: Optional[str] = None
    spart_no: Optional[str] = None
    stock_dt: Optional[date] = None

    yn: Optional[str] = None


# ============================================================
#                   LEDGER CREATE + RESPONSE
# ============================================================
class LedgerCreate(LedgerBase):
    store_id: Optional[int] = None
    Master_id: Optional[int] = None
    @model_validator(mode="after")
    def validate_required(self):
        if not self.Ledger_code:
            raise ValueError("Ledger_code cannot be empty")
        return self


class LedgerResponse(LedgerBase):
    ledger_id: int
    store_id: Optional[int] = None
    Master_id: Optional[int] = None

    model_config = ConfigDict(from_attributes=True)


# ============================================================
#              LEDGER MAINTENANCE BASE MODELS
# ============================================================
class LedgerMaintenanceBase(BaseModel):
    ledger_page: Optional[str] = None

    ohs_number: Optional[str] = None
    isg_number: Optional[str] = None
    ssg_number: Optional[str] = None

    part_number: Optional[str] = None
    nomenclature: Optional[str] = None
    a_u: Optional[str] = None

    no_off: Optional[int] = None
    scl_auth: Optional[int] = None

    unsv_stock: Optional[int] = None
    rep_stock: Optional[int] = None
    serv_stock: Optional[int] = None

    msc: Optional[Literal["M", "S", "C"]] = None
    ved: Optional[Literal["V", "E", "D"]] = None
    in_house: Optional[Literal["in_house", "ORD"]] = None

    dues_in: Optional[int] = None
    consumption: Optional[int] = None

    bin_number: Optional[str] = None
    group: Optional[str] = None

    cds_unsv_stock: Optional[int] = None
    cds_rep_stock: Optional[int] = None
    cds_serv_stock: Optional[int] = None

    br_stock: Optional[int] = None
    br_stock_dt: Optional[date] = None

    cab: Optional[str] = None
    dem: Optional[int] = None
    dem_val: Optional[float] = None

    lock_dt: Optional[date] = None

    npart_no: Optional[str] = None
    nscl_no: Optional[str] = None

    old_page: Optional[str] = None

    p_stock_dt: Optional[date] = None
    qty: Optional[int] = None

    r_stock: Optional[int] = None
    r_stock_dt: Optional[date] = None

    sale_rate: Optional[float] = None
    sl: Optional[str] = None
    spart_no: Optional[str] = None
    stock_dt: Optional[date] = None

    yn: Optional[str] = None


# ============================================================
#           LEDGER MAINTENANCE CREATE
# ============================================================
class LedgerMaintanenceCreate(LedgerMaintenanceBase):
    cos_sec: str
    cab_no: str
    old_pg_ref: float
    Assy_Comp: str
    Re_ord_lvl: int
    safety_stk: int

    @model_validator(mode="after")
    def validate_fields(self):
        for name, value in self.model_dump().items():
            if isinstance(value, int) and value < 0:
                raise ValueError(f"{name} must be >= 0")
            if isinstance(value, str) and not value.strip():
                raise ValueError(f"{name} cannot be empty")
        return self


# ============================================================
#           LEDGER MAINTENANCE UPDATE  ✅ FIXED
# ============================================================
class LedgerMaintanenceUpdate(LedgerMaintenanceBase):
    cos_sec: Optional[str] = None
    cab_no: Optional[str] = None
    old_pg_ref: Optional[float] = None
    Assy_Comp: Optional[str] = None
    Re_ord_lvl: Optional[int] = None
    safety_stk: Optional[int] = None

    @model_validator(mode="after")
    def validate_fields(self):
        for name, value in self.model_dump(exclude_none=True).items():
            if isinstance(value, int) and value < 0:
                raise ValueError(f"{name} must be >= 0")
        return self

    model_config = ConfigDict(extra="ignore")


# ============================================================
#                LEDGER MAINTENANCE RESPONSE
# ============================================================
class LedgerMaintenanceResponse(LedgerMaintenanceBase):
    lpp: Optional[str] = None
    rate: Optional[float] = None
    Rmks: Optional[str] = None
    lpp_dt: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)
