from .routes import router as admin_router

__all__ = ["admin_router"]
