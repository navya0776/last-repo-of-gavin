# # # import asyncio

# # # from fastapi import APIRouter, Depends, HTTPException, Query, status
# # # from backend.schemas import (
# # #     LedgerMaintanenceCreate,
# # #     LedgerMaintanenceUpdate,
# # #     LedgerMaintenanceResponse,
# # # )
# # # from backend.schemas.ledger.stk_analysis import StockAnalysisResult
# # # from backend.schemas.ledger.ledgers import StoreResponse

# # # from backend.services.ledger import (
# # #     add_page,
# # #     get_all_ledgers,
# # #     get_could_change_analysis,
# # #     get_desirable_analysis,
# # #     get_essential_analysis,
# # #     get_item_analysis,
# # #     get_ledger_pages,
# # #     get_msc_analysis,
# # #     get_must_change_analysis,
# # #     get_non_scaled_item_analysis,
# # #     get_scaled_item_analysis,
# # #     get_shoud_change_analysis,
# # #     get_ved_analysis,
# # #     get_vital_analysis,
# # #     update_page,
# # # )
# # # from backend.utils.users import UserPermissions
# # # from sqlalchemy.ext.asyncio import AsyncSession
# # # from data.database import get_db

# # # router = APIRouter()


# # # @router.get("/", response_model=list[StoreResponse])
# # # async def get_all_ledger(
# # #     permissions: UserPermissions,
# # #     skip: int = 0,
# # #     limit: int = 100,
# # #     session: AsyncSession = Depends(get_db),
# # # ):
# # #     if permissions.ledger.read:
# # #         return await get_all_ledgers(session, skip, limit)

# # #     raise HTTPException(
# # #                 status_code=status.HTTP_401_UNAUTHORIZED, detail="Read permissions not found!"
# # #     )


# # # @router.get("/{ledger_code}", response_model=list[LedgerMaintenanceResponse])
# # # async def get_ledger_page(
# # #     permissions: UserPermissions,
# # #     ledger_code: str,
# # #     skip: int = 0,
# # #     limit: int = 100,
# # #     session: AsyncSession = Depends(get_db),
# # # ):
# # #     if permissions.ledger.read:
# # #         return await get_ledger_pages(ledger_code, session, skip, limit)

# # #     raise HTTPException(
# # #         status_code=status.HTTP_401_UNAUTHORIZED, detail="Read permissions not found!"
# # #     )


# # # @router.post("/{ledger_code}")
# # # async def add_ledger_page(
# # #     permissions: UserPermissions,
# # #     ledger_page: LedgerMaintanenceCreate,
# # #     ledger_code: str ,
# # #     session: AsyncSession = Depends(get_db),
# # # ):
# # #     if not permissions.ledger.read:
# # #         raise HTTPException(
# # #             status_code=status.HTTP_401_UNAUTHORIZED,
# # #             detail="Read permissions not found!",
# # #         )
# # #     if permissions.ledger.write:
# # #         return await add_page(ledger_code, ledger_page, session)

# # #     raise HTTPException(
# # #         status_code=status.HTTP_401_UNAUTHORIZED,
# # #         detail="No write permissions",
# # #     )


# # # @router.put("/")
# # # async def update_ledger_page(
# # #     permissions: UserPermissions,
# # #     ledger_page: LedgerMaintanenceUpdate,
# # #     ledger_code: str = Query(...),
# # #     session: AsyncSession = Depends(get_db),
# # # ):
# # #     if not permissions.ledger.read:
# # #         raise HTTPException(
# # #             status_code=status.HTTP_401_UNAUTHORIZED,
# # #             detail="Read permissions not found!",
# # #         )

# # #     if permissions.ledger.write:
# # #         return await update_page(ledger_code, ledger_page, session)

# # #     raise HTTPException(
# # #         status_code=status.HTTP_401_UNAUTHORIZED,
# # #         detail="No write permissions",
# # #     )


# # # @router.post("/analysis", response_model=StockAnalysisResult)
# # # async def ledger_analysis(
# # #     permissions: UserPermissions,
# # #     ledger_code: str = Query(...),
# # #     session: AsyncSession = Depends(get_db),
# # # ):
# # #     if not permissions.ledger.read:
# # #         raise HTTPException(
# # #             status_code=status.HTTP_401_UNAUTHORIZED, detail="No read permissions"
# # #         )
# # #     (
# # #         no_of_items,
# # #         scaled_items,
# # #         non_scaled_items,
# # #         msc,
# # #         must_change,
# # #         should_change,
# # #         could_change,
# # #         ved,
# # #         vital,
# # #         essential,
# # #         desirable,
# # #     ) = await asyncio.gather(
# # #         get_item_analysis(ledger_code, session),
# # #         get_scaled_item_analysis(ledger_code, session),
# # #         get_non_scaled_item_analysis(ledger_code, session),
# # #         get_msc_analysis(ledger_code, session),
# # #         get_must_change_analysis(ledger_code, session),
# # #         get_shoud_change_analysis(ledger_code, session),
# # #         get_could_change_analysis(ledger_code, session),
# # #         get_ved_analysis(ledger_code, session),
# # #         get_vital_analysis(ledger_code, session),
# # #         get_essential_analysis(ledger_code, session),
# # #         get_desirable_analysis(ledger_code, session),
# # #     )

# # #     return StockAnalysisResult(
# # #         no_of_items=no_of_items,
# # #         scl_itms=scaled_items,
# # #         nsc_itms=non_scaled_items,
# # #         ved=ved,
# # #         vital=vital,
# # #         essential=essential,
# # #         desirable=desirable,
# # #         msc=msc,
# # #         mst_chng=must_change,
# # #         cld_chng=could_change,
# # #         shld_chng=should_change,
# # #     )

# # # updating the ledger id  code issue

# # import sys
# # print("PYTHONPATH =", sys.path)


# # import asyncio
# # from typing import Optional, List

# # from fastapi import APIRouter, Depends, HTTPException, Query, status
# # from sqlalchemy.ext.asyncio import AsyncSession
# # from sqlalchemy import select

# # from backend.schemas import (
# #     LedgerMaintanenceCreate,
# #     LedgerMaintanenceUpdate,
# #     LedgerMaintenanceResponse,
# # )
# # from backend.schemas.ledger.stk_analysis import StockAnalysisResult
# # from backend.schemas.ledger.ledgers import StoreResponse

# # from backend.services.ledger import (
# #     add_page,
# #     get_all_ledgers,
# #     get_could_change_analysis,
# #     get_desirable_analysis,
# #     get_essential_analysis,
# #     get_item_analysis,
# #     get_ledger_pages,
# #     get_msc_analysis,
# #     get_must_change_analysis,
# #     get_non_scaled_item_analysis,
# #     get_scaled_item_analysis,
# #     get_shoud_change_analysis,
# #     get_ved_analysis,
# #     get_vital_analysis,
# # )

# # from backend.utils.users import UserPermissions
# # from data.models.ledgers import Ledger
# # from data.database import get_db

# # router = APIRouter()

# # # ============================================================
# # # GET ALL STORES + LEDGERS
# # # ============================================================
# # @router.get("/", response_model=List[StoreResponse])
# # async def get_all_ledger(
# #     permissions: UserPermissions,
# #     skip: int = 0,
# #     limit: int = 100,
# #     session: AsyncSession = Depends(get_db),
# # ):
# #     if not permissions.ledger.read:
# #         raise HTTPException(
# #             status_code=status.HTTP_401_UNAUTHORIZED,
# #             detail="Read permissions not found!",
# #         )

# #     return await get_all_ledgers(session, skip, limit)


# # # ============================================================
# # # GET LEDGER PAGES
# # # ============================================================
# # @router.get("/{ledger_code}", response_model=List[LedgerMaintenanceResponse])
# # async def get_ledger_page(
# #     permissions: UserPermissions,
# #     ledger_code: str,
# #     skip: int = 0,
# #     limit: int = 100,
# #     session: AsyncSession = Depends(get_db),
# # ):
# #     if not permissions.ledger.read:
# #         raise HTTPException(
# #             status_code=status.HTTP_401_UNAUTHORIZED,
# #             detail="Read permissions not found!",
# #         )

# #     return await get_ledger_pages(ledger_code, session, skip, limit)


# # # ============================================================
# # # ADD LEDGER PAGE
# # # ============================================================
# # @router.post("/{ledger_code}")
# # async def add_ledger_page(
# #     permissions: UserPermissions,
# #     ledger_page: LedgerMaintanenceCreate,
# #     ledger_code: str,
# #     session: AsyncSession = Depends(get_db),
# # ):
# #     if not permissions.ledger.read:
# #         raise HTTPException(
# #             status_code=status.HTTP_401_UNAUTHORIZED,
# #             detail="Read permissions not found!",
# #         )

# #     if not permissions.ledger.write:
# #         raise HTTPException(
# #             status_code=status.HTTP_401_UNAUTHORIZED,
# #             detail="No write permissions",
# #         )

# #     return await add_page(ledger_code, ledger_page, session)


# # # ============================================================
# # # UPDATE LEDGER PAGE  🔥 FIXED
# # # ============================================================
# # @router.put("/")
# # async def update_ledger_page(
# #     permissions: UserPermissions,
# #     ledger_page: LedgerMaintanenceUpdate,
# #     ledger_code: str = Query(...),
# #     session: AsyncSession = Depends(get_db),
# # ):
# #     if not permissions.ledger.read:
# #         raise HTTPException(
# #             status_code=status.HTTP_401_UNAUTHORIZED,
# #             detail="Read permissions not found!",
# #         )

# #     if not permissions.ledger.write:
# #         raise HTTPException(
# #             status_code=status.HTTP_401_UNAUTHORIZED,
# #             detail="No write permissions",
# #         )

# #     # 🔍 Fetch row
# #     q = await session.execute(
# #         select(LedgerMaintenance)
# #         .where(LedgerMaintenance.ledger_code == ledger_code)
# #     )
# #     row = q.scalars().first()

# #     if not row:
# #         raise HTTPException(
# #             status_code=status.HTTP_404_NOT_FOUND,
# #             detail=f"Ledger {ledger_code} not found",
# #         )

# #     # 🔥 Partial update only
# #     data = ledger_page.model_dump(exclude_none=True)

# #     for key, value in data.items():
# #         setattr(row, key, value)

# #     await session.commit()
# #     await session.refresh(row)

# #     return {"success": True, "ledger_code": ledger_code}


# # # ============================================================
# # # LEDGER ANALYSIS
# # # ============================================================
# # @router.post("/analysis", response_model=StockAnalysisResult)
# # async def ledger_analysis(
# #     permissions: UserPermissions,
# #     ledger_code: str = Query(...),
# #     session: AsyncSession = Depends(get_db),
# # ):
# #     if not permissions.ledger.read:
# #         raise HTTPException(
# #             status_code=status.HTTP_401_UNAUTHORIZED,
# #             detail="No read permissions",
# #         )

# #     (
# #         no_of_items,
# #         scaled_items,
# #         non_scaled_items,
# #         msc,
# #         must_change,
# #         should_change,
# #         could_change,
# #         ved,
# #         vital,
# #         essential,
# #         desirable,
# #     ) = await asyncio.gather(
# #         get_item_analysis(ledger_code, session),
# #         get_scaled_item_analysis(ledger_code, session),
# #         get_non_scaled_item_analysis(ledger_code, session),
# #         get_msc_analysis(ledger_code, session),
# #         get_must_change_analysis(ledger_code, session),
# #         get_shoud_change_analysis(ledger_code, session),
# #         get_could_change_analysis(ledger_code, session),
# #         get_ved_analysis(ledger_code, session),
# #         get_vital_analysis(ledger_code, session),
# #         get_essential_analysis(ledger_code, session),
# #         get_desirable_analysis(ledger_code, session),
# #     )

# #     return StockAnalysisResult(
# #         no_of_items=no_of_items,
# #         scl_itms=scaled_items,
# #         nsc_itms=non_scaled_items,
# #         ved=ved,
# #         vital=vital,
# #         essential=essential,
# #         desirable=desirable,
# #         msc=msc,
# #         mst_chng=must_change,
# #         cld_chng=could_change,
# #         shld_chng=should_change,
# #     )

# import sys
# print("PYTHONPATH =", sys.path)

# import asyncio
# from typing import List

# from fastapi import APIRouter, Depends, HTTPException, Query, status
# from sqlalchemy.ext.asyncio import AsyncSession
# from sqlalchemy import select

# from backend.schemas import (
#     LedgerMaintanenceCreate,
#     LedgerMaintanenceUpdate,
#     LedgerMaintenanceResponse,
# )
# from backend.schemas.ledger.stk_analysis import StockAnalysisResult
# from backend.schemas.ledger.ledgers import StoreResponse

# from backend.services.ledger import (
#     add_page,
#     get_all_ledgers,
#     get_could_change_analysis,
#     get_desirable_analysis,
#     get_essential_analysis,
#     get_item_analysis,
#     get_ledger_pages,
#     get_msc_analysis,
#     get_must_change_analysis,
#     get_non_scaled_item_analysis,
#     get_scaled_item_analysis,
#     get_shoud_change_analysis,
#     get_ved_analysis,
#     get_vital_analysis,
# )

# from backend.utils.users import UserPermissions
# from data.models.ledgers import Ledger   # ✅ THIS IS THE ONLY MODEL
# from data.database import get_db

# router = APIRouter()

# # ============================================================
# # GET ALL STORES + LEDGERS
# # ============================================================
# @router.get("/", response_model=List[StoreResponse])
# async def get_all_ledger(
#     permissions: UserPermissions,
#     skip: int = 0,
#     limit: int = 100,
#     session: AsyncSession = Depends(get_db),
# ):
#     if not permissions.ledger.read:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="Read permissions not found!",
#         )

#     return await get_all_ledgers(session, skip, limit)


# # ============================================================
# # GET LEDGER PAGES
# # ============================================================
# @router.get("/{ledger_code}", response_model=List[LedgerMaintenanceResponse])
# async def get_ledger_page(
#     permissions: UserPermissions,
#     ledger_code: str,
#     skip: int = 0,
#     limit: int = 100,
#     session: AsyncSession = Depends(get_db),
# ):
#     if not permissions.ledger.read:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="Read permissions not found!",
#         )

#     return await get_ledger_pages(ledger_code, session, skip, limit)


# # ============================================================
# # ADD LEDGER PAGE
# # ============================================================
# @router.post("/{ledger_code}")
# async def add_ledger_page(
#     permissions: UserPermissions,
#     ledger_page: LedgerMaintanenceCreate,
#     ledger_code: str,
#     session: AsyncSession = Depends(get_db),
# ):
#     if not permissions.ledger.read:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="Read permissions not found!",
#         )

#     if not permissions.ledger.write:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="No write permissions",
#         )

#     return await add_page(ledger_code, ledger_page, session)


# # ============================================================
# # UPDATE LEDGER PAGE  ✅ FIXED PROPERLY
# # ============================================================
# @router.put("/")
# async def update_ledger_page(
#     permissions: UserPermissions,
#     ledger_page: LedgerMaintanenceUpdate,
#     ledger_code: str = Query(...),
#     session: AsyncSession = Depends(get_db),
# ):
#     if not permissions.ledger.read:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="Read permissions not found!",
#         )

#     if not permissions.ledger.write:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="No write permissions",
#         )

#     # 🔍 Fetch ledger row (CORRECT MODEL)
#     result = await session.execute(
#         select(Ledger).where(Ledger.Ledger_code == ledger_code)
#     )
#     ledger = result.scalars().first()

#     if not ledger:
#         raise HTTPException(
#             status_code=status.HTTP_404_NOT_FOUND,
#             detail=f"Ledger {ledger_code} not found",
#         )

#     # 🔥 Partial update (only sent fields)
#     update_data = ledger_page.model_dump(exclude_none=True)

#     for field, value in update_data.items():
#         setattr(ledger, field, value)

#     await session.commit()
#     await session.refresh(ledger)

#     return {
#         "success": True,
#         "ledger_code": ledger_code,
#     }


# # ============================================================
# # LEDGER ANALYSIS
# # ============================================================
# @router.post("/analysis", response_model=StockAnalysisResult)
# async def ledger_analysis(
#     permissions: UserPermissions,
#     ledger_code: str = Query(...),
#     session: AsyncSession = Depends(get_db),
# ):
#     if not permissions.ledger.read:
#         raise HTTPException(
#             status_code=status.HTTP_401_UNAUTHORIZED,
#             detail="No read permissions",
#         )

#     (
#         no_of_items,
#         scaled_items,
#         non_scaled_items,
#         msc,
#         must_change,
#         should_change,
#         could_change,
#         ved,
#         vital,
#         essential,
#         desirable,
#     ) = await asyncio.gather(
#         get_item_analysis(ledger_code, session),
#         get_scaled_item_analysis(ledger_code, session),
#         get_non_scaled_item_analysis(ledger_code, session),
#         get_msc_analysis(ledger_code, session),
#         get_must_change_analysis(ledger_code, session),
#         get_shoud_change_analysis(ledger_code, session),
#         get_could_change_analysis(ledger_code, session),
#         get_ved_analysis(ledger_code, session),
#         get_vital_analysis(ledger_code, session),
#         get_essential_analysis(ledger_code, session),
#         get_desirable_analysis(ledger_code, session),
#     )

#     return StockAnalysisResult(
#         no_of_items=no_of_items,
#         scl_itms=scaled_items,
#         nsc_itms=non_scaled_items,
#         ved=ved,
#         vital=vital,
#         essential=essential,
#         desirable=desirable,
#         msc=msc,
#         mst_chng=must_change,
#         cld_chng=could_change,
#         shld_chng=should_change,
#     )

import sys
print("PYTHONPATH =", sys.path)

import asyncio
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from backend.schemas import (
    LedgerMaintanenceCreate,
    LedgerMaintanenceUpdate,
    LedgerMaintenanceResponse,
)
from backend.schemas.ledger.stk_analysis import StockAnalysisResult
from backend.schemas.ledger.ledgers import StoreResponse

from backend.services.ledger import (
    add_page,
    get_all_ledgers,
    get_could_change_analysis,
    get_desirable_analysis,
    get_essential_analysis,
    get_item_analysis,
    get_ledger_pages,
    get_msc_analysis,
    get_must_change_analysis,
    get_non_scaled_item_analysis,
    get_scaled_item_analysis,
    get_shoud_change_analysis,
    get_ved_analysis,
    get_vital_analysis,
)

from backend.utils.users import UserPermissions
from data.models.ledgers import Ledger   # ✅ CORRECT MODEL
from data.database import get_db

router = APIRouter()

# ============================================================
# GET ALL STORES + LEDGERS
# ============================================================
@router.get("/", response_model=List[StoreResponse])
async def get_all_ledger(
    permissions: UserPermissions = Depends(),
    skip: int = 0,
    limit: int = 100,
    session: AsyncSession = Depends(get_db),
):
    if not permissions.ledger.read:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Read permissions not found!",
        )

    return await get_all_ledgers(session, skip, limit)


# ============================================================
# GET LEDGER PAGES
# ============================================================
@router.get("/{ledger_code}", response_model=List[LedgerMaintenanceResponse])
async def get_ledger_page(
    permissions: UserPermissions,
    ledger_code: str,
    skip: int = 0,
    limit: int = 100,
    session: AsyncSession = Depends(get_db),
):
    if not permissions.ledger.read:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Read permissions not found!",
        )

    return await get_ledger_pages(ledger_code, session, skip, limit)


# ============================================================
# ADD LEDGER PAGE
# ============================================================
@router.post("/{ledger_code}")
async def add_ledger_page(
    permissions: UserPermissions,
    ledger_page: LedgerMaintanenceCreate,
    ledger_code: str,
    session: AsyncSession = Depends(get_db),
):
    if not permissions.ledger.read:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Read permissions not found!",
        )

    if not permissions.ledger.write:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="No write permissions",
        )

    return await add_page(ledger_code, ledger_page, session)


# ============================================================
# UPDATE LEDGER PAGE  ✅ FIXED
# ============================================================
@router.put("/")
async def update_ledger_page(
    permissions: UserPermissions,
    ledger_page: LedgerMaintanenceUpdate,
    ledger_code: str = Query(...),
    session: AsyncSession = Depends(get_db),
):
    if not permissions.ledger.read:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Read permissions not found!",
        )

    if not permissions.ledger.write:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="No write permissions",
        )

    # 🔍 Fetch ledger row (FIXED MODEL)
    result = await session.execute(
        select(Ledger).where(Ledger.Ledger_code == ledger_code)
    )
    ledger = result.scalars().first()

    if not ledger:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Ledger {ledger_code} not found",
        )

    # 🔥 SAFE partial update
    update_data = {
        k: v
        for k, v in ledger_page.model_dump(exclude_none=True).items()
        if not (isinstance(v, str) and v.strip() == "")
    }

    for field, value in update_data.items():
        setattr(ledger, field, value)

    await session.commit()
    await session.refresh(ledger)

    return {
        "success": True,
        "ledger_code": ledger_code,
    }


# ============================================================
# LEDGER ANALYSIS
# ============================================================
@router.post("/analysis", response_model=StockAnalysisResult)
async def ledger_analysis(
    permissions: UserPermissions,
    ledger_code: str = Query(...),
    session: AsyncSession = Depends(get_db),
):
    if not permissions.ledger.read:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="No read permissions",
        )

    (
        no_of_items,
        scaled_items,
        non_scaled_items,
        msc,
        must_change,
        should_change,
        could_change,
        ved,
        vital,
        essential,
        desirable,
    ) = await asyncio.gather(
        get_item_analysis(ledger_code, session),
        get_scaled_item_analysis(ledger_code, session),
        get_non_scaled_item_analysis(ledger_code, session),
        get_msc_analysis(ledger_code, session),
        get_must_change_analysis(ledger_code, session),
        get_shoud_change_analysis(ledger_code, session),
        get_could_change_analysis(ledger_code, session),
        get_ved_analysis(ledger_code, session),
        get_vital_analysis(ledger_code, session),
        get_essential_analysis(ledger_code, session),
        get_desirable_analysis(ledger_code, session),
    )

    return StockAnalysisResult(
        no_of_items=no_of_items,
        scl_itms=scaled_items,
        nsc_itms=non_scaled_items,
        ved=ved,
        vital=vital,
        essential=essential,
        desirable=desirable,
        msc=msc,
        mst_chng=must_change,
        cld_chng=could_change,
        shld_chng=should_change,
    )
